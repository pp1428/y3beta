/*
 * Stage 1 sanity check: lists all OpenCL platforms and devices visible
 * to the system. Build and run this first to confirm your OpenCL
 * headers/ICD loader/driver are set up correctly before touching any
 * kernel code.
 */

#include <stdio.h>
#include <stdlib.h>
#include <CL/cl.h>

int main(void) {
    cl_uint num_platforms = 0;
    clGetPlatformIDs(0, NULL, &num_platforms);

    if (num_platforms == 0) {
        printf("No OpenCL platforms found. Check that an ICD loader and a\n"
               "vendor driver (Intel/AMD) are installed.\n");
        return 1;
    }

    cl_platform_id *platforms = malloc(sizeof(cl_platform_id) * num_platforms);
    clGetPlatformIDs(num_platforms, platforms, NULL);

    printf("Found %u OpenCL platform(s):\n\n", num_platforms);

    for (cl_uint i = 0; i < num_platforms; i++) {
        char name[256] = {0}, vendor[256] = {0}, version[256] = {0};
        clGetPlatformInfo(platforms[i], CL_PLATFORM_NAME, sizeof(name), name, NULL);
        clGetPlatformInfo(platforms[i], CL_PLATFORM_VENDOR, sizeof(vendor), vendor, NULL);
        clGetPlatformInfo(platforms[i], CL_PLATFORM_VERSION, sizeof(version), version, NULL);

        printf("Platform %u: %s\n", i, name);
        printf("  Vendor:  %s\n", vendor);
        printf("  Version: %s\n", version);

        cl_uint num_devices = 0;
        clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, 0, NULL, &num_devices);
        if (num_devices == 0) {
            printf("  No devices found on this platform.\n\n");
            continue;
        }

        cl_device_id *devices = malloc(sizeof(cl_device_id) * num_devices);
        clGetDeviceIDs(platforms[i], CL_DEVICE_TYPE_ALL, num_devices, devices, NULL);

        for (cl_uint j = 0; j < num_devices; j++) {
            char dname[256] = {0};
            cl_device_type dtype = 0;
            clGetDeviceInfo(devices[j], CL_DEVICE_NAME, sizeof(dname), dname, NULL);
            clGetDeviceInfo(devices[j], CL_DEVICE_TYPE, sizeof(dtype), &dtype, NULL);

            const char *type_str =
                (dtype & CL_DEVICE_TYPE_GPU) ? "GPU" :
                (dtype & CL_DEVICE_TYPE_CPU) ? "CPU" : "OTHER";

            printf("  Device %u [%s]: %s\n", j, type_str, dname);
        }
        printf("\n");
        free(devices);
    }

    free(platforms);
    return 0;
}
