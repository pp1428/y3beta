/*
 * Stage 2 (CPU reference): determinant of a square matrix via Gaussian
 * elimination with partial pivoting (pivot chosen by largest |value|
 * in the column). Benchmarks sizes 32, 64, 128, 256, 512 with random
 * double matrices and prints CSV: size,time_sec,determinant
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

static double *alloc_matrix(int n) {
    return (double *)malloc(sizeof(double) * (size_t)n * (size_t)n);
}

static void fill_random(double *A, int n, unsigned int seed) {
    srand(seed);
    for (int i = 0; i < n * n; i++) {
        /* values in [1.0, 100.0) to keep the matrix well away from singular */
        A[i] = (double)(rand() % 10000) / 100.0 + 1.0;
    }
}

/* Destroys A (reduces it to upper-triangular form in place).
 * Writes the sign-adjusted log10 of |det| into *log10_abs_det (useful
 * because the raw determinant of a large random matrix routinely
 * overflows double — this is expected, not a bug, and the log form
 * stays meaningful for the report). Returns the raw determinant too,
 * which may legitimately be +-inf for large n. */
static double determinant_gauss(double *A, int n, double *log10_abs_det, int *out_sign) {
    int sign = 1;

    for (int k = 0; k < n; k++) {
        int pivot = k;
        double maxval = fabs(A[k * n + k]);
        for (int i = k + 1; i < n; i++) {
            double v = fabs(A[i * n + k]);
            if (v > maxval) {
                maxval = v;
                pivot = i;
            }
        }

        if (maxval < 1e-12) {
            *log10_abs_det = -INFINITY;
            *out_sign = 0;
            return 0.0; /* singular (or numerically singular) */
        }

        if (pivot != k) {
            for (int j = 0; j < n; j++) {
                double tmp = A[k * n + j];
                A[k * n + j] = A[pivot * n + j];
                A[pivot * n + j] = tmp;
            }
            sign = -sign;
        }

        double diag = A[k * n + k];
        for (int i = k + 1; i < n; i++) {
            double factor = A[i * n + k] / diag;
            if (factor == 0.0) continue;
            for (int j = k; j < n; j++) {
                A[i * n + j] -= factor * A[k * n + j];
            }
        }
    }

    double det = (double)sign;
    double log10_sum = 0.0;
    for (int i = 0; i < n; i++) {
        det *= A[i * n + i];
        log10_sum += log10(fabs(A[i * n + i]));
    }
    *log10_abs_det = log10_sum;
    *out_sign = sign;
    return det;
}

static double now_sec(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int main(void) {
    const int sizes[] = {32, 64, 128, 256, 512};
    const int nsizes = (int)(sizeof(sizes) / sizeof(sizes[0]));

    printf("size,time_sec,determinant,sign,log10_abs_det\n");

    for (int s = 0; s < nsizes; s++) {
        int n = sizes[s];
        double *A = alloc_matrix(n);
        if (!A) {
            fprintf(stderr, "Allocation failed for n=%d\n", n);
            return 1;
        }
        fill_random(A, n, 42u + (unsigned)n);

        double log10_abs_det = 0.0;
        int sign = 1;

        double t0 = now_sec();
        double det = determinant_gauss(A, n, &log10_abs_det, &sign);
        double t1 = now_sec();

        /* det itself may legitimately be +-inf for large n (see note
         * on determinant_gauss above) — log10_abs_det stays finite and
         * is the number to actually plot/report for size>=~200. */
        printf("%d,%.6f,%.6e,%d,%.4f\n", n, t1 - t0, det, sign, log10_abs_det);

        free(A);
    }

    return 0;
}
