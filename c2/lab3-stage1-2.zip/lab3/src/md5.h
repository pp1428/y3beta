#ifndef MD5_H
#define MD5_H

#include <stdint.h>
#include <stddef.h>

typedef struct {
    uint32_t state[4];
    uint64_t count;       /* total bytes processed */
    unsigned char buffer[64];
} MD5_CTX;

void md5_init(MD5_CTX *ctx);
void md5_update(MD5_CTX *ctx, const unsigned char *data, size_t len);
void md5_final(MD5_CTX *ctx, unsigned char digest[16]);

/* Convenience: hash a buffer in one call. */
void md5_compute(const unsigned char *data, size_t len, unsigned char digest[16]);

/* Convert a 16-byte digest to a 32-char lowercase hex string (+ '\0'). */
void md5_to_hex(const unsigned char digest[16], char hex[33]);

#endif /* MD5_H */
