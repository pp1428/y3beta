/*
 * Stage 2 (CPU reference): MD5 bruteforce over a fixed alphabet.
 *
 * Two modes:
 *
 *   1) Benchmark mode (no args): for each length 1..5, generate a random
 *      password of that length, hash it, then brute-force it back and
 *      report the time. Prints CSV:
 *        len,password,hash,time_sec,found
 *
 *   2) Target mode: md5_bruteforce_cpu <target_md5_hex> <max_length>
 *      Tries every length from 1 up to max_length against the given
 *      32-char hex MD5 digest and reports the match + time per length.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "md5.h"

static const char ALPHABET[] =
    "abcdefghijklmnopqrstuvwxyz"
    "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "0123456789";
static const int ALPHABET_LEN = (int)(sizeof(ALPHABET) - 1);

#define MAX_CANDIDATE_LEN 12

static double now_sec(void) {
    struct timespec ts;
    timespec_get(&ts, TIME_UTC);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

/* Tries every candidate of exactly `len` characters. Returns 1 and fills
 * `result` if found, 0 otherwise. */
static int try_length(const char *target_hex, int len, char *result) {
    char candidate[MAX_CANDIDATE_LEN + 1];
    candidate[len] = '\0';

    unsigned char digest[16];
    char hex[33];

    long long total = 1;
    for (int i = 0; i < len; i++) total *= ALPHABET_LEN;

    for (long long n = 0; n < total; n++) {
        long long t = n;
        for (int i = 0; i < len; i++) {
            candidate[i] = ALPHABET[t % ALPHABET_LEN];
            t /= ALPHABET_LEN;
        }

        md5_compute((const unsigned char *)candidate, (size_t)len, digest);
        md5_to_hex(digest, hex);

        if (strcmp(hex, target_hex) == 0) {
            strcpy(result, candidate);
            return 1;
        }
    }
    return 0;
}

static int run_target_mode(const char *target_hex, int max_len) {
    char result[MAX_CANDIDATE_LEN + 1];

    printf("length,time_sec,found\n");
    for (int len = 1; len <= max_len; len++) {
        double t0 = now_sec();
        int found = try_length(target_hex, len, result);
        double t1 = now_sec();

        if (found) {
            printf("%d,%.6f,%s\n", len, t1 - t0, result);
            return 0;
        }
        printf("%d,%.6f,(none)\n", len, t1 - t0);
    }
    fprintf(stderr, "Not found up to length %d\n", max_len);
    return 1;
}

static int run_benchmark_mode(void) {
    printf("len,password,hash,time_sec,found\n");
    srand(12345u);

    for (int len = 1; len <= 5; len++) {
        char pw[MAX_CANDIDATE_LEN + 1];
        for (int i = 0; i < len; i++) {
            pw[i] = ALPHABET[rand() % ALPHABET_LEN];
        }
        pw[len] = '\0';

        unsigned char digest[16];
        char hex[33];
        md5_compute((const unsigned char *)pw, (size_t)len, digest);
        md5_to_hex(digest, hex);

        char result[MAX_CANDIDATE_LEN + 1];
        double t0 = now_sec();
        int found = try_length(hex, len, result);
        double t1 = now_sec();

        printf("%d,%s,%s,%.6f,%s\n", len, pw, hex, t1 - t0,
               found ? result : "NOT FOUND");
    }
    return 0;
}

int main(int argc, char **argv) {
    if (argc >= 3) {
        const char *target = argv[1];
        int max_len = atoi(argv[2]);
        if (max_len < 1 || max_len > MAX_CANDIDATE_LEN) {
            fprintf(stderr, "max_length must be between 1 and %d\n", MAX_CANDIDATE_LEN);
            return 1;
        }
        return run_target_mode(target, max_len);
    }

    return run_benchmark_mode();
}
