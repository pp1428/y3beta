# ЛР3 — определитель матрицы + MD5-брутфорс (CPU → OpenCL)

Архив покрывает Этап 1 (окружение) и Этап 2 (CPU-эталон) из плана.
Этапы 3–5 (OpenCL-ядра, замеры GPU, отчёт) добавим следующими шагами.

## Структура

```
lab3/
├── .vscode/
│   ├── tasks.json            # сборка через gcc (Ctrl+Shift+B)
│   ├── c_cpp_properties.json # пути для IntelliSense
│   └── launch.json           # запуск под gdb
├── src/
│   ├── determinant_cpu.c     # определитель, метод Гаусса (CPU)
│   ├── md5.h / md5.c         # своя реализация MD5 (RFC 1321)
│   ├── md5_bruteforce_cpu.c  # брутфорс MD5 по алфавиту (CPU)
│   └── opencl_platform_info.c# проверка окружения OpenCL (Этап 1)
├── Makefile                  # альтернатива задачам VS Code
└── build/                    # сюда попадают .exe после сборки
```

## Этап 1 — окружение (Windows 11, MSYS2/MinGW)

В терминале **MSYS2 MinGW64**:

```bash
pacman -S mingw-w64-x86_64-opencl-headers mingw-w64-x86_64-opencl-icd
pacman -S clinfo   # опционально, для проверки
clinfo             # должны увидеться платформы/устройства
```

Открой папку `lab3` в VS Code (с расширением C/C++ от Microsoft), затем:

1. Собери `opencl_platform_info` (`Ctrl+Shift+B` → выбери эту задачу, либо `make opencl-check`).
2. Запусти `build/opencl_platform_info.exe` — он выведет список платформ и устройств OpenCL. Если список пуст, проверь, установлен ли драйвер OpenCL от Intel/AMD.

Если пути в `.vscode/c_cpp_properties.json` и `tasks.json` у тебя отличаются
(например, MSYS2 стоит не в `C:/msys64`), поправь их под свою систему.

## Этап 2 — CPU-эталон

Собери всё сразу (задача по умолчанию `Ctrl+Shift+B`, либо `make cpu`):

```bash
make cpu
```

### Определитель (метод Гаусса, выбор ведущего элемента)

```bash
./build/determinant_cpu.exe
```

Печатает CSV `size,time_sec,determinant` для размеров 32, 64, 128, 256, 512
со случайными матрицами `double`.

### MD5-брутфорс

Два режима:

```bash
# Режим замера: для длин 1..5 сам генерирует пароль, хэширует и подбирает обратно
./build/md5_bruteforce_cpu.exe

# Режим "подобрать конкретный хэш": перебор длин 1..max_length
./build/md5_bruteforce_cpu.exe 5f4dcc3b5aa765d61d8327deb882cf99 4
```

Первая команда печатает CSV `len,password,hash,time_sec,found` — это и есть
данные для таблицы "CPU" из плана.

## Дальше

Когда замеры CPU готовы и окружение OpenCL подтверждено `clinfo`/`opencl_platform_info`,
переходим к Этапу 3: ядра OpenCL для определителя и MD5-брутфорса. Пришли мне,
как соберётся этот архив и отработают обе CPU-программы — продолжим с кернелов.
