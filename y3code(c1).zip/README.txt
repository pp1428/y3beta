ЛР3 ЯП — OpenCL. Инструкция по сборке и запуску
=================================================

Структура папки:
  CPU/
    det_cpu.c          — определитель матрицы (метод Гаусса), CPU
    bruteforce_cpu.c   — брутфорс SHA-256, CPU
    sha256.h           — своя реализация SHA-256 (используется CPU и GPU host-кодом)
  GPU/
    det_kernel.cl       — OpenCL-ядро для определителя
    det_host.c           — host-программа для определителя (GPU)
    bf_kernel.cl         — OpenCL-ядро для брутфорса
    bf_host.c            — host-программа для брутфорса (GPU)
    sha256.h             — нужен только для формирования эталонного хэша в bf_host.c

У вас уже есть папка OLSDK (OpenCL SDK) — судя по скриншоту, она лежит в
...\лб3япы\Игнатова_OpenCL\OLSDK\, внутри должны быть подпапки include\ и lib\.
Используем её так же, как в примере с которого вы начинали (gcc -I ... -L ... -l OpenCL).


1. CPU-часть (не требует OpenCL, работает везде)
-------------------------------------------------
Откройте консоль (cmd / PowerShell / терминал MinGW) в папке CPU и выполните:

    gcc -O2 -o det_cpu.exe det_cpu.c -lm
    det_cpu.exe > det_cpu_results.csv
    type det_cpu_results.csv

    gcc -O2 -o bruteforce_cpu.exe bruteforce_cpu.c -lm
    bruteforce_cpu.exe > bruteforce_cpu_results.csv
    type bruteforce_cpu_results.csv

(На Linux/macOS — те же команды, только .exe не нужен и вместо `type` используйте `cat`.)

Это даст РЕАЛЬНЫЕ тайминги вашего CPU — именно их и нужно подставить в отчёт
вместо/вместе с моими оценочными.


2. GPU-часть (нужен OpenCL SDK — у вас это папка OLSDK)
---------------------------------------------------------
Перейдите в папку GPU и соберите host-программы, указав пути к include/ и lib/
из вашей OLSDK (поправьте путь под свой компьютер, как в вашем старом примере):

    gcc -o det_host.exe det_host.c ^
        -I "C:\_tr\y3nogit\лб3япы\Игнатова_OpenCL\OLSDK\include" ^
        -L "C:\_tr\y3nogit\лб3япы\Игнатова_OpenCL\OLSDK\lib\x86_64" ^
        -l OpenCL

    gcc -o bf_host.exe bf_host.c ^
        -I "C:\_tr\y3nogit\лб3япы\Игнатова_OpenCL\OLSDK\include" ^
        -L "C:\_tr\y3nogit\лб3япы\Игнатова_OpenCL\OLSDK\lib\x86_64" ^
        -l OpenCL

(`^` — перенос строки в cmd.exe; в PowerShell используйте `` ` ``, в bash — `\`.)

ВАЖНО: .cl-файл с ядром должен лежать РЯДОМ с .exe (в текущей рабочей папке),
так как host-программа открывает его по относительному имени
("det_kernel.cl" / "bf_kernel.cl"). Либо скопируйте .cl в папку с .exe,
либо запускайте .exe из папки GPU — тогда всё сработает как есть.

Запуск:

    det_host.exe
    bf_host.exe

Если при запуске выводится "Error: ..." — см. раздел "Возможные проблемы" ниже.

Чтобы снять тайминги на GPU самостоятельно (в коде сейчас выводится только
результат, не время), оберните вызов clEnqueueNDRangeKernel + clFinish
замером времени, например через QueryPerformanceCounter (Windows) или
clGetEventProfilingInfo (если создать очередь с CL_QUEUE_PROFILING_ENABLE).
Простой вариант — замерить время вокруг всего цикла шагов k (для det_host.c)
или вокруг clEnqueueNDRangeKernel (для bf_host.c) через <time.h>:

    clock_t t0 = clock();
    ... вызовы clEnqueue... + clFinish(queue) ...
    clock_t t1 = clock();
    printf("GPU time: %.3f ms\n", 1000.0*(t1-t0)/CLOCKS_PER_SEC);


3. Проверка, что видит ваша система (опционально)
----------------------------------------------------
В папке clinfoGUISources (судя по скриншоту) у вас уже есть утилита для
просмотра доступных OpenCL-платформ/устройств — соберите и запустите её
(или просто скачайте готовый clinfo.exe), чтобы убедиться, что GPU вообще
виден системе через OpenCL, прежде чем разбираться с ошибками сборки.


4. Возможные проблемы
------------------------
- "cannot find -lOpenCL" / "OpenCL.lib not found" — неверный путь в -L,
  проверьте, что в OLSDK\lib\x86_64 лежит OpenCL.lib (MSVC) или libOpenCL.a /
  libOpenCL.dll.a (MinGW). Если у вас только MSVC-версия lib, собирайте через
  cl.exe (MSVC), а не gcc, либо найдите MinGW-совместимую OpenCL SDK
  (например, из состава драйвера видеокарты или пакета `opencl-headers` +
  `ocl-icd` на Linux).
- "Error: creating context" / "Error: creating command queue" — на вашей
  машине нет GPU-устройства, видимого OpenCL (ноутбук без дискретной видео-
  карты, либо не установлен ICD-драйвер). В этом случае замените
  CL_DEVICE_TYPE_GPU на CL_DEVICE_TYPE_CPU в det_host.c / bf_host.c — многие
  CPU тоже имеют свой OpenCL-рантайм (Intel CPU Runtime for OpenCL, POCL) и
  код всё равно запустится, просто не на видеокарте.
- Долгое выполнение bf_host.c — пароль "zzzzz" (длина 5) намеренно выбран
  как последний (худший) кандидат в пространстве перебора; для быстрой
  проверки можно временно уменьшить passLen до 3-4 в main().


5. Что в итоге подставить в отчёт
------------------------------------
Замените в таблицах 1 и 2 отчёта (ЛР3_ЯП_OpenCL.docx) столбцы "CPU, мс" и
"GPU, мс" на значения, полученные у вас реально, пересчитайте столбец
"Ускорение" = CPU/GPU и, если хотите, попросите меня перестроить графики и
текст выводов под ваши настоящие цифры — пришлите мне получившиеся CSV/числа.
